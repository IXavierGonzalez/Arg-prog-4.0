const infoOculta= document.getElementsByClassName("infoOculta");
const boton= document.getElementsByClassName("boton");
const mostrarInfo =()=>{
    for (let i=0; i<infoOculta.length; i++){
        if (boton[i].innerHTML=='Más'){
            infoOculta[i].style.display= "block";
            boton[i].innerHTML = 'Menos'
        }else{
            infoOculta[i].style.display= "none";
            boton[i].innerHTML='Más'
        }
    }
}